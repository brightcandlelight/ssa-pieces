#ifndef UTILS_H
#define UTILS_H

int printfv(const char* format, ...);

#endif
