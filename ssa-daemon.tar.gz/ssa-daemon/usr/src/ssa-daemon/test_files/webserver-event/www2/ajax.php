<?php
        echo 'Dynamic Content Here';
?>

